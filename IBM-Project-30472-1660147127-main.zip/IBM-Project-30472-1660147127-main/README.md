

# Smart Waste Management System For Metropolitan Cities
TECHNOLOGY : IOT <br>
TEAM ID : PNT2022TMID15973

## 👨‍👩‍👦TEAM MEMBERS
- Dharneeshwaran  G B   
- Arun K
- Aswin Kumar  V
- Ananda Sailesh


## 📒PROJECT DESCRIPTION:
<br>In simple words, Smart Waste Management is a waste management process to identify the amount of trash in the trash bin and helps to notify the Waste management team to clear them up and the Trash bin's place can be obtained with the help of GPS.  <br>


## Skills Required:
IBM Cloud,IBM Cloud Object Storage,Python,IBM Watson IoT Platform,Node-RED service,Cloudant DB.
